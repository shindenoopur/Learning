import React from "react";
import ReactDom from "react-dom";

class externalFileComponent extends React.Component{
    render(){
       return <p>This is child component which is written in externalFile.js</p>
    }
}

export default externalFileComponent