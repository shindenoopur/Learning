// import React from 'react';
// import ReactDOM from 'react-dom';
// import App from './App';
// import './index.css';

// ReactDOM.render(
//   <App />,
//   document.getElementById('root')
// );


// import React from "react";
// import reactDom from "react-dom";

// reactDom.render(<p>Hello World!!</p>, document.getElementById('insertContent'));

import React from 'react';
import ReactDOM from 'react-dom';
// import './externalFile.js'
import ExternalFileComponent from './externalFile.js';
import './App.css'

const ytableDemo = (
  <div>
  <table>
    <tbody>
    <tr> 
      <th>Name</th>
    </tr>
    
    <tr>
      <td>User1</td>
    </tr>

    <tr>
      <td>User2</td>
    </tr>
    </tbody>
  </table>

  <h1>Used two components table and h1</h1>
  </div>
)
// ReactDOM.render(ytableDemo, document.getElementById('root'));

class ComponentClass extends React.Component{
  constructor() {
    super();
    this.state = {property1: "yellow"};
  }

  /*Called after component is rendered. Used to run statements which require componnent in DOM */
  componentDidMount(){
    setTimeout(() => {
      this.setState({property1:"component Did Mount"})
    }, 1000

    )
  }

  /*If component is not to be updated */
  // shouldComponentUpdate(){
    // return false;
  // }

  changeState = () => {
    this.setState({property1:"(prop changed using setState)"})
  }

  /* Used to access the prev states and props value before updation */
  getSnapshotBeforeUpdate(oldprops, oldstates){
    document.getElementById("oldstatediv").innerHTML =
    "Before the update, property1 " + oldstates.property1;
    
  }
  componentDidUpdate(){
    document.getElementById("oldStateDiv2").innerHTML =
    "After the update, property1 " + this.state.property1;
  }
  
  render(){
    const toBeSentVar = {name: "Test variable sent", desc: 1};
    return (<div><h2>Component class name should always begin with {this.state.property1} capital letter. Child component data <ChildComponentClass property2="set directly" property3={toBeSentVar.desc} /></h2>
    <button type="button" onClick={this.changeState}>change property</button>
    <div id="oldstatediv"></div>
    <div id="oldStateDiv2"></div>
    </div>)
  }
}

/*Using components inside other components using <ChildClassComponent /> */
class ChildComponentClass extends React.Component{
  render(){
  return <div><p>This is a {this.props.property2} and {this.props.property3} child component</p></div>
  }

}

// ReactDOM.render(<ComponentClass />, document.getElementById("root"))

function ComponentExample(){
  return <h2>Component function used to render HTML content</h2>
}

//  ReactDOM.render(<ComponentExample />, document.getElementById("root"))
ReactDOM.render(<div><h3>This Index.js component</h3><ExternalFileComponent /></div>, document.getElementById("root"))

/* Form interaction */
class DemoForm extends React.Component{
  constructor(props){
    super(props);
    this.state = {user: "Demo user",age: null, textareabox:"The text is set in value attribute of textarea", dropdownbox: "Option1", errorMessage:""};
  }

  stateHandlerDemo = (event) => {
    let name = event.target.name;
    let value =  event.target.value;
    let err=""
    this.setState({[name]: value})
    this.setState({errorMessage: ""});
    this.setState({textareabox: "UpdatedTextUpdatedTextUpdatedTextUpdatedTextUpdatedTextUpdatedTextUpdatedTextUpdatedText"});
    this.setState({dropdownbox: value})
    
    if(name==="age"){
      if(value==="" || !Number(value)){
        err = <h3 style={{color:"red"}}>Age must be a number</h3>;
        
      }
    }
    this.setState({errorMessage: err})
  }

  DemoSubmit = (event) => {
    event.preventDefault()    //Prevents actual form submission
    
    if(this.state.user === "" || this.state.age ===null || !Number(this.state.age))
      alert("Please enter valid information in all fields")
    else
      alert("You are about to submit the information")
  }
  
  render(){
    let headerElement;
    if(this.state.user === "" || this.state.age == null){
      headerElement = <h1>Please enter the information</h1>
    }
    else{
      headerElement =  <h1>Hello {this.state.user} Age: {this.state.age}</h1>
    }

    const internalCSS = {
      color:"#000",
      backgroundColor:"#008000",
      fontFamily:"Arial",
      fontSize: 25,
      width:275
    }

    return(
      <form onSubmit={this.DemoSubmit}>
        {headerElement}
        <textarea value={this.state.textareabox} onChange={this.stateHandlerDemo}></textarea>
        <select value={this.state.dropdownbox}  onChange={this.stateHandlerDemo}>
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
        </select>
        <p>Enter your name:
          <input type="text" name="user" onChange={this.stateHandlerDemo}></input>
        </p>
        <p>Enter your Age:
          <input type="text" name="age" onChange={this.stateHandlerDemo}></input>
        </p>
        <input type="submit" /><br></br>
      {this.state.errorMessage}
      <p style={{color:"#fff", backgroundColor:"#0077b3", width: 275}}>This is styled using inline CSS.</p>
      <p style={internalCSS}>This is styled using internal CSS.</p>
      <p className="democss">This is styled using external CSS.</p>
      </form>
    )}
}

// ReactDOM.render(<DemoForm />, document.getElementById("root"))