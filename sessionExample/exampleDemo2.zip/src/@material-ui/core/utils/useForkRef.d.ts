export default function useForkRef<T>(refA: React.Ref<T>, refB: React.Ref<T>): React.Ref<T>;
