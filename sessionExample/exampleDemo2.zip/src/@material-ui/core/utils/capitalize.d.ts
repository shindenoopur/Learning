export default function capitalize(str: string): string;
