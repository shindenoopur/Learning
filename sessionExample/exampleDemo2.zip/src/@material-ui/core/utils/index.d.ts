export { default as ownerWindow } from './ownerWindow';
export { default as requirePropFactory } from './requirePropFactory';
