import { Theme } from './createMuiTheme';

export default function useTheme<T = Theme>(): T;
