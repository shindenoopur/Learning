/**
 * The default theme interface, augment this to avoid having to set the theme type everywhere
 */
export interface DefaultTheme {}
