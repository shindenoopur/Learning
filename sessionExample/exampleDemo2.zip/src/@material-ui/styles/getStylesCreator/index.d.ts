export { default } from './getStylesCreator';
export * from './getStylesCreator';
