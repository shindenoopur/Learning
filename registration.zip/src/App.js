import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './App.css';

class Application extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      isLoginOpen: true,
      isRegisterOpen: false
    };
  }

  signIn(username) {
    alert("SIGNINs")
    // This is where you would call Firebase, an API etc...
    // calling setState will re-render the entire app (efficiently!)
    this.setState({
      user:username
    })
  }

  showRegisterBox(){
    this.setState({isRegisterOpen:true, isLoginOpen:false})
  }

  showLoginBox(){
    this.setState({isLoginOpen:true, isRegisterOpen:false})
  }

  
  render() {

    return (
      <div className="root-container">

        <div className="box-controller" >
          <div className={"controller " + (this.state.isLoginOpen
            ? "selected-controller"
            : "")}  onClick={this.showLoginBox.bind(this)}>
            Login
          </div>
          <div className={"controller " + (this.state.isRegisterOpen
            ? "selected-controller"
            : "")} onClick={this.showRegisterBox.bind(this)}>
            Register
          </div>
        </div>
        <div className="box-container">
          {this.state.isLoginOpen && <LoginBox />}
          {this.state.isRegisterOpen && <RegisterBox />}
        </div>
      </div>
    );
  }
};



const Welcome = ({user, onSignOut})=> {
  // This is a dumb "stateless" component
  return (
    <div>
      Welcome <strong>{user}</strong>!
      <a href="javascript:;" onClick={onSignOut}>Sign out</a>
    </div>
  )
}


class LoginBox extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      username:null
    };
  }

  submitLogin(e){
    alert("In SumbitLogin"),
    e.preventDefault();
    let uname = this.refs.username.value;
    console.log(uname);
    this.signIn(uname).bind(this)
  }

  render(){
    return(
    <div className="inner-container">
      <div className="box-header">
        Login
      </div>
      <div className="box">
        <div className="input-group">
          <label htmlFor="username">Username</label> 
          <input type="text" className="login-input" ref="username" name="username" placeholder="userName" />
        </div>
        <div className="input-group">
          <label htmlFor="password">Password</label> 
          <input type="password" className="login-input" name="password" placeholder="password" />
        </div>
      <button type="button" className="login-input" onClick={this.submitLogin.bind(this)}>Login</button>   
      </div>
    </div>
    );
  }
}


class RegisterBox extends React.Component{
  constructor(props){
    super(props);
    this.state = { username:'', email:'', password:'', errors: [], passwordState: null };
  }

  showValidationError(element, msg){
    this.setState((prevState) => ({
      errors: [...prevState.errors, {element, msg}]
    }))
  }

  clearValidationError(element){
    this.setState((prevState) => {
      let newArr = []
      for(let err of prevState.errors){
        if(element !== err.element){
          newArr.push(err)
        }
      }
      return {errors: newArr};
    });
  }

  onUsernameChange(e){
    this.setState({username:e.target.value})
    this.clearValidationError("username")
  }

  onemailChange(e){
    this.setState({email: e.target.value})
    this.clearValidationError("email")
  }

  onPasswordChange(e){
    this.setState({password: e.target.value})
    this.clearValidationError("password")

    this.setState({passwordState:"weak"})
    if(e.target.value.length>8){
      this.setState({passwordState:"medium"})
    }if(e.target.value.length > 12){
      this.setState({passwordState:"strong"})
    }
  }

  submitRegister(e){
    if(this.state.username === ""){
      this.showValidationError("username", "Username cannot be empty")
    }
    if(this.state.email === ""){
      this.showValidationError("email", "Email cannot be empty")
    }
    if(this.state.password === ""){
      this.showValidationError("password", "password cannot be empty")
    }

    e.preventDefault();
  }

  render(){

    let usernameErr = null, emailErr = null, passwordErr = null;
    let passwordWeak=false, passwordMedium = false, passwordStrong=false;

    console.log("passwordMedium", this.state.passwordState)
    if(this.state.passwordState === "weak"){
      passwordWeak = true;
    }else if(this.state.passwordState === "medium"){
      passwordWeak=true;
      passwordMedium=true;
    }else if(this.state.passwordState === "strong"){passwordMedium=true;
      passwordWeak=true;
      passwordMedium = true;
      passwordStrong=true;
    }

    for(let err of this.state.errors){
      if(err.element === "username"){
        usernameErr = err.msg;
      }if(err.element === "email"){
        emailErr = err.msg;
      }if(err.element === "password"){
        passwordErr = err.msg
      }
    }

    return(
    <div className="inner-container">
      <div className="box-header">
        Register
      </div>
      <form className="box">
        <div className="input-group">
          <label htmlFor="username">Username</label> 
          <input type="text" className="login-input" name="username" placeholder="userName" onChange={this.onUsernameChange.bind(this)}/>
        <small className="danger-error">{usernameErr ? usernameErr : ""}</small>
        </div> 
        <div className="input-group">
          <label htmlFor="email">Email</label> 
          <input type="email" className="login-input" name="email" placeholder="enter email" onChange={this.onemailChange.bind(this)}/>
        <small className="danger-error">{emailErr ? emailErr : ""}</small>
        </div>
        <div className="input-group">
          <label htmlFor="password">Password</label> 
          <input type="password" className="login-input" name="password" placeholder="password" onChange={this.onPasswordChange.bind(this)}/>
        <small className="danger-error">{passwordErr ? passwordErr : ""}</small>
        </div>

        {this.state.password && <div className="password-state">
          <div className={"pwd pwd-weak " + (passwordWeak ? "show": "")}>

          </div>
          <div className={"pwd pwd-medium " + (passwordMedium ? "show": "")}>

          </div>
          <div className={"pwd pwd-strong " + (passwordStrong ? "show": "")}>

          </div>
        </div>}
      <button type="button" className="login-input" onClick={this.submitRegister.bind(this)}>Register</button>   
      </form>
    </div>
    );
  }
}


export default Application